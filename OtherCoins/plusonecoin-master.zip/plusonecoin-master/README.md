PlusOne Coin
============

https://plusonecoin.org

What is PlusOne Coin?
---------------------

...coming soon...

License
-------

PlusOne Coin is released under the terms of the MIT license. See [COPYING](COPYING) for more
information or see https://opensource.org/licenses/MIT.

Credits
-------

PlusOneCoin was forked from Bitcoin Core
* [bitcoin](https://github.com/bitcoin/bitcoin)
* [CryptoCoderz](https://github.com/CryptoCoderz/Espers.git) HMQ1725
